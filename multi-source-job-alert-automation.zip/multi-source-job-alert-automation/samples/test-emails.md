# Unique Test Emails

Use these only for workflow testing. Each sample contains a different job ID and URL.

## LinkedIn Test

**Subject:** LinkedIn Job Alert: Web Scraping Specialist — Test 20260814-LI-001

```text
New job matching your alert

Position: Web Scraping Specialist
Company: Atlas Data Systems
Location: Remote
Job Type: Part-time
Salary: USD 8–12 per hour
Description: Build and maintain Python scraping workflows using Playwright, Selenium, and Pandas.
Apply: https://example.com/linkedin/jobs/20260814-LI-001
Job ID: 20260814-LI-001
```

## OnlineJobs.ph Test

**Subject:** New OnlineJobs.ph Opportunity — Test 20260814-OJ-002

```text
Position: Data Collection and Lead Research Assistant
Company: Northstar Research Co.
Location: Remote — Philippines
Job Type: Part-time
Salary: USD 5–7 per hour
Description: Collect, clean, categorize, and deduplicate business lead data using spreadsheets and web research.
Apply: https://example.com/onlinejobs/jobs/20260814-OJ-002
Job ID: 20260814-OJ-002
```

## ChatGPT Email Alert Test

**Subject:** Job Alert: n8n Automation Developer — Test 20260814-CG-003

```text
Position: Junior n8n Automation Developer
Company: FlowWorks Studio
Location: Remote
Job Type: Project-based
Salary: USD 300–500 per project
Description: Build n8n workflows connecting Gmail, Google Sheets, APIs, and Telegram with filtering and deduplication.
Apply: https://example.com/chatgpt/jobs/20260814-CG-003
Job ID: 20260814-CG-003
```

## Duplicate Test

After a sample succeeds, send the exact same message again. The second copy should stop at the duplicate-check path and should not create another row or Telegram alert.
