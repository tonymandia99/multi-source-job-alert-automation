# Workflow Export

Place the sanitized n8n export in this directory with this filename:

```text
multi-source-job-alert-workflow.json
```

Before publishing the JSON:

- Remove or anonymize credential references.
- Remove personal email addresses.
- Remove Telegram bot tokens and chat IDs.
- Replace the Google spreadsheet ID with a placeholder.
- Remove real job applicant or employer information.
- Confirm the JSON imports into a clean n8n workflow.

In n8n, open the completed workflow, select the workflow menu, and choose **Download** or **Export**. The exact label may vary by n8n version.
